
--Init addon
AddCSLuaFile()

if SERVER then
	AddCSLuaFile( "core_ultraslide/cl_ultraslide.lua" )
	include( "core_ultraslide/sv_ultraslide.lua" )
	print( 2 )
else
	include( "core_ultraslide/cl_ultraslide.lua" )
	print( 1 )
end