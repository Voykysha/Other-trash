-- ultraslide_server.lua

ultraSlideEnabled = 1
sparksEnabled = 1
playerSlideDirection = {}
playerSlideSpeed = {}
playerIsSliding = {}
slideSound = "player/slide.mp3"
slideEndSound = "player/slide_end.mp3"
slideSoundInterval = 11

util.AddNetworkString("UltraSlide_PlaySound")
util.AddNetworkString("UltraSlide_StopSound")
util.AddNetworkString("UltraSlide_Sparks")

concommand.Add("set_ultraslide", function(ply, cmd, args)
	local value = tonumber(args[1])
	if value == 1 then
		ultraSlideEnabled = 1
		ply:ChatPrint("Мод ULTRASLIDE включен.")
	elseif value == 0 then
		ultraSlideEnabled = 0
		ply:ChatPrint("Мод ULTRASLIDE выключен.")
	else
		ply:ChatPrint("Некорректное значение. Используйте 1 для включения и 0 для выключения.")
	end
end)

concommand.Add("set_sparks", function(ply, cmd, args)
	local value = tonumber(args[1])
	if value == 1 then
		sparksEnabled = 1
		ply:ChatPrint("Искры включены.")
	elseif value == 0 then
		sparksEnabled = 0
		ply:ChatPrint("Искры выключены.")
	else
		ply:ChatPrint("Некорректное значение. Используйте 1 для включения и 0 для выключения.")
	end
end)

concommand.Add("set_slide_speed", function(ply, cmd, args)
	local value = tonumber(args[1])
	if value then
		playerSlideSpeed[ply] = value
		ply:ChatPrint("Скорость скольжения установлена на " .. value .. ".")
	else
		ply:ChatPrint("Некорректное значение. Укажите число для скорости.")
	end
end)

local function BroadcastSlideSound(ply)
	net.Start("UltraSlide_PlaySound")
		net.WriteEntity(ply)
	net.Broadcast()
end

local function BroadcastStopSound(ply)
	net.Start("UltraSlide_StopSound")
		net.WriteEntity(ply)
	net.Broadcast()
end
local function BroadcastSparks(ply)
	if not playerSlideDirection[ply] then return end

	local dir = playerSlideDirection[ply]

	-- Отправляем эффект владельцу
	net.Start("UltraSlide_Sparks")
		net.WriteEntity(ply)
		net.WriteVector(dir)
	net.Send(ply)

	-- Отправляем всем остальным (если игрок в зоне видимости)
	for _, other in ipairs(player.GetAll()) do
		if other ~= ply and other:GetPos():DistToSqr(ply:GetPos()) < 250000 then -- 500^2
			net.Start("UltraSlide_Sparks")
				net.WriteEntity(ply)
				net.WriteVector(dir)
			net.Send(other)
		end
	end
end



local function StopSliding(ply)
	if playerIsSliding[ply] then
		print("inside StopSliding1")
		BroadcastStopSound(ply)
		playerIsSliding[ply] = false
		playerSlideDirection[ply] = nil
		timer.Remove("SlideSoundTimer_" .. ply:EntIndex())
	end
end

local function SetPlayerSlideAnimation(ply)
	if not IsValid(ply) or not ply:Alive() then return end
	ply:AnimRestartGesture(GESTURE_SLOT_CUSTOM, ACT_MP_CROUCHWALK, true)
	ply:SetPlaybackRate(1.5)
end

hook.Add("SetupMove", "UltraSlide", function(ply, mv)
	if ultraSlideEnabled == 1 and ply:Alive() and ply:KeyDown(IN_DUCK) and ply:IsOnGround() then
		if not playerSlideDirection[ply] then
			local forward = Vector(0, 0, 0)
			local right = Vector(0, 0, 0)

			if ply:KeyDown(IN_FORWARD) then
				forward = mv:GetAngles():Forward()
			elseif ply:KeyDown(IN_BACK) then
				forward = -mv:GetAngles():Forward()
			end

			if ply:KeyDown(IN_MOVELEFT) then
				right = -mv:GetAngles():Right()
			elseif ply:KeyDown(IN_MOVERIGHT) then
				right = mv:GetAngles():Right()
			end

			if forward == Vector(0, 0, 0) and right == Vector(0, 0, 0) then
				forward = mv:GetAngles():Forward()
			end

			playerSlideDirection[ply] = forward + right
			playerSlideDirection[ply].z = 0
			playerSlideDirection[ply]:Normalize()

			if not playerSlideSpeed[ply] then
				playerSlideSpeed[ply] = 550
			end

			BroadcastSlideSound(ply)
			playerIsSliding[ply] = true

			timer.Create("SlideSoundTimer_" .. ply:EntIndex(), slideSoundInterval, 0, function()
				if playerIsSliding[ply] and ply:IsOnGround() then
					BroadcastSlideSound(ply)
				else
					StopSliding(ply)
				end
			end)
		end

		BroadcastSparks(ply)
		SetPlayerSlideAnimation(ply)

		local slideDirection = playerSlideDirection[ply]
		local slideSpeed = playerSlideSpeed[ply] or 550
		local sideMovement = mv:GetSideSpeed() * 0.01

		local velocity = slideDirection * slideSpeed + mv:GetAngles():Right() * sideMovement
		mv:SetVelocity(Vector(velocity.x, velocity.y, mv:GetVelocity().z))
	elseif playerIsSliding[ply] and ply:KeyDown(IN_JUMP) then
		local slideDirection = playerSlideDirection[ply] or Vector(0, 0, 0)
		local slideSpeed = playerSlideSpeed[ply] or 550
		mv:SetVelocity(Vector(slideDirection.x * slideSpeed, slideDirection.y * slideSpeed, mv:GetVelocity().z))

		if not ply:KeyDown(IN_DUCK) or not ply:IsOnGround() then
			StopSliding(ply)
		end
	else
		StopSliding(ply)
	end
end)

hook.Add("PlayerFootstep", "DisableFootstepsWhileSliding", function(ply, pos, foot, sound, volume, filter)
	if ultraSlideEnabled == 1 and ply:KeyDown(IN_DUCK) then
		return true
	end
end)
