-- ultraslide_client.lua

slideSound = "player/slide.mp3"
slideEndSound = "player/slide_end.mp3"
playerSlideDirection = playerSlideDirection or {}
sparksEnabled = sparksEnabled or 1

local activeSounds = {}

net.Receive("UltraSlide_PlaySound", function()
	local ply = net.ReadEntity()
	if not IsValid(ply) then return end

	local snd = CreateSound(ply, slideSound)
	if snd then
		snd:Play()
		activeSounds[ply] = snd
	end
end)

net.Receive("UltraSlide_StopSound", function()
	local ply = net.ReadEntity()
	if not IsValid(ply) then return end

	if activeSounds[ply] then
		activeSounds[ply]:Stop()
		activeSounds[ply] = nil
	end

	ply:EmitSound(slideEndSound)
end)

net.Receive("UltraSlide_Sparks", function()
	local ply = net.ReadEntity()
	local dir = net.ReadVector()
	if not IsValid(ply) then return end
	if sparksEnabled == 0 then return end

	local forwardPos = ply:GetPos() + dir:GetNormalized() * 20
	local effectData = EffectData()
	effectData:SetOrigin(forwardPos)
	effectData:SetNormal(dir)
	effectData:SetMagnitude(2)
	effectData:SetScale(1)
	effectData:SetRadius(5)
	util.Effect("Sparks", effectData)
end)

